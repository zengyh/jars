// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IStarter.java

package com.sinitek.base.starter;

import java.util.Properties;

public interface IStarter
{

    public abstract void start(Properties properties)
        throws Exception;
}
