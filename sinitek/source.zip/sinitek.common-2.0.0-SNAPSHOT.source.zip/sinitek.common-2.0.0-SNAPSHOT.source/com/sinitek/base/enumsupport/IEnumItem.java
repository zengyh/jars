// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IEnumItem.java

package com.sinitek.base.enumsupport;


public interface IEnumItem
{

    public abstract String getEnumName();

    public abstract String getEnumItemName();

    public abstract String getEnumItemInfo();

    public abstract int getEnumItemValue();

    public abstract String getEnumItemDisplayValue();
}
