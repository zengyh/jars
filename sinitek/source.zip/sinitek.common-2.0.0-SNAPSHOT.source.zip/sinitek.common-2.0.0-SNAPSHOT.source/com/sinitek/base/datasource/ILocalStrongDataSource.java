// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ILocalStrongDataSource.java

package com.sinitek.base.datasource;


// Referenced classes of package com.sinitek.base.datasource:
//            IStrongDataSource

public interface ILocalStrongDataSource
    extends IStrongDataSource
{
}
