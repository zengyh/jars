// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AbsChartTag.java

package com.sinitek.spirit.webcontrol.tag.chart;

import com.sinitek.spirit.webcontrol.tag.ui.Component;
import org.apache.log4j.Logger;
import org.apache.struts2.views.jsp.ui.AbstractClosingTag;

abstract class AbsChartTag extends AbstractClosingTag
{

    AbsChartTag()
    {
    }

    public static final Logger LOG = Logger.getLogger(com/sinitek/spirit/webcontrol/tag/ui/Component);

}
