// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DemoDwr.java

package com.sinitek.spirit.webcontrol.demo;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public class DemoDwr
{

    public DemoDwr()
    {
    }

    public String test(Map param, HttpServletRequest request)
    {
        return "Hello World";
    }
}
