// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IDemoObject2.java

package com.sinitek.spirit.webcontrol.demo;

import com.sinitek.base.metadb.IMetaObjectImpl;

public interface IDemoObject2
    extends IMetaObjectImpl
{

    public abstract String getName();

    public abstract void setName(String s);

    public static final String ENTITY_NAME = "DEMOOBJECT2";
}
